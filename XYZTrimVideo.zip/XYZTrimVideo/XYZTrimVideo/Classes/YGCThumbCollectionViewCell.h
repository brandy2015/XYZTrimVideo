//
//  YGCThumbCollectionViewCell.h
//  VideoTrimView
//
//  Created by Qilong Zang on 30/01/2018.
//  Copyright © 2018 Qilong Zang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YGCThumbCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *thumbImageView;

@end
